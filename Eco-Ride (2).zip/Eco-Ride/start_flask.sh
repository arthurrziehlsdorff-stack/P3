#!/bin/bash
cd server_python && python app.py
